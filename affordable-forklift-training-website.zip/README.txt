AFFORDABLE FORKLIFT TRAINING WEBSITE

Files:
- index.html — complete one-page website with embedded generated images.

Quick setup:
1. Upload index.html to your web host as the homepage.
2. Point your domain to the hosting account.
3. For best SEO, connect Google Search Console and submit your sitemap once your domain is live.
4. The contact buttons use tel: and mailto: links. For reliable website form submissions, replace the mailto form with your preferred form service or backend.

Note:
The website is intentionally lightweight and self-contained. Images are embedded directly in the HTML so there are no extra image files to manage.
